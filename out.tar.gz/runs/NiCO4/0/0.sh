#!/bin/bash
#SBATCH -t 5:00:00
#SBATCH -o out.txt
cd $WORK/gaussian/runs/NiCO4/0

g16 < NiCO4_HF.gj> NiCO4_HF.out