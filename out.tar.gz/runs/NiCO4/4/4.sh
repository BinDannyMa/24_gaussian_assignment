#!/bin/bash
#SBATCH -t 5:00:00
#SBATCH -o out.txt
cd $WORK/gaussian/runs/NiCO4/4
g16 < NiCO4_AM1.gj > NiCO4_AM1.out