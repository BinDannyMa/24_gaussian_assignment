#!/bin/bash
#SBATCH -t 5:00:00
#SBATCH -o out.txt
cd $WORK/gaussian/runs/NiCO4/5
g16 < NiCO4_MNDO.gj > NiCO4_MNDO.out