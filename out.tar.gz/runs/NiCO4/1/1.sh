#!/bin/bash
#SBATCH -t 5:00:00
#SBATCH -o out.txt
cd $WORK/gaussian/runs/NiCO4/1
g16 < NiCO4_MP2.gj > NiCO4_MP2.out