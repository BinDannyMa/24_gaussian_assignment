#!/bin/bash
#SBATCH -t 5:00:00
#SBATCH -o out.txt
cd $WORK/gaussian/runs/NiCO4/2
g16 < NiCO4_CCSD.gj > NiCO4_CCSD.out