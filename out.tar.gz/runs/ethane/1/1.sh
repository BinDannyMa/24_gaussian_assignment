#!/bin/bash
#SBATCH -t 5:00:00
#SBATCH -o out.txt
cd $WORK/gaussian/runs/ethane/1
g16 < ethane_MP2.gj > ethane_MP2.out