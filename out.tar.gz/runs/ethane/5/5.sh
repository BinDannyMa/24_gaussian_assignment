#!/bin/bash
#SBATCH -t 5:00:00
#SBATCH -o out.txt
cd $WORK/gaussian/runs/ethane/5
g16 < ethane_MNDO.gj > ethane_MNDO.out