#!/bin/bash
#SBATCH -t 5:00:00
#SBATCH -o out.txt
cd $WORK/gaussian/runs/ethane/2
g16 < ethane_CCSD.gj > ethane_CCSD.out