#!/bin/bash
#SBATCH -t 5:00:00
#SBATCH -o out.txt
cd $WORK/gaussian/runs/ethane/4
g16 < ethane_AM1.gj > ethane_AM1.out