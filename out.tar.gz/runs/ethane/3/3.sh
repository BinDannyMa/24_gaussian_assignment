#!/bin/bash
#SBATCH -t 5:00:00
#SBATCH -o out.txt
cd $WORK/gaussian/runs/ethane/3
g16 < ethane_B3LYP.gj > ethane_B3LYP.out