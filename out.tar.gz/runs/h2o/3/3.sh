#!/bin/bash
#SBATCH -t 5:00:00
#SBATCH -o out.txt
cd $WORK/gaussian/runs/h2o/3
g16 < h2o_B3LYP.gj > h2o_B3LYP.out