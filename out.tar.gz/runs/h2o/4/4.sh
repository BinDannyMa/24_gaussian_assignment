#!/bin/bash
#SBATCH -t 5:00:00
#SBATCH -o out.txt
cd $WORK/gaussian/runs/h2o/4
g16 < h2o_AM1.gj > h2o_AM1.out