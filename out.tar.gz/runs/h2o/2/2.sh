#!/bin/bash
#SBATCH -t 5:00:00
#SBATCH -o out.txt
cd $WORK/gaussian/runs/h2o/2
g16 < h2o_CCSD.gj > h2o_CCSD.out